const express = require('express');
const router = express.Router();
module.exports = router;
// Display a list of

router.post('/Add', (req, res) => {
    const { first_name, last_name  } = req.body;

    const query = 'INSERT INTO employees (last_name , first_name ) VALUES (?, ?)';
    const values = [first_name, last_name];


    db_pool.query(query, values, (err, result) => {
        if (err) {
            console.error('Error adding employee:', err);
            res.status(500).json({ error: 'Internal server error' });
            return;
        }

        res.status(201).json({ message: 'Employees added successfully' });
    });
});


// Render the form for editing an employee
router.get('/Edit/:id', (req, res) => {
    const employeeId = req.params.id;

    // Fetch the employee data from the database based on the ID
    db_pool.query('SELECT * FROM employees WHERE id = $1', [employeeId], (err, result) => {
        if (err) {
            // Handle the error
            console.error(err);
            res.status(500).send('Internal Server Error');
        } else {
            // Render an edit form with the fetched employee data
            res.render('EditEmployee', { employee: result.rows[0] });
        }
    });
});

// Handle the submission of the form to edit an employee
router.post('/Edit/:id', (req, res) => {
    const employeeId = req.params.id;
    // Extract updated employee data from the request body
    const { firstName, lastName } = req.body;

    // Update the employee in the database based on the provided ID
    db_pool.query(
        'UPDATE employees SET first_name = $1, last_name = $2 WHERE id = $3',
        [firstName, lastName, employeeId],
        (err) => {
            if (err) {
                // Handle the error
                console.error(err);
                res.status(500).send('Internal Server Error');
            } else {
                // Redirect to the list of employees or show a success message
                res.redirect('/employees');
            }
        }
    );
});

// Handle the deletion of an employee
router.post('/Delete/:id/', (req, res) => {
    const employeeId = req.params.id;

    // Delete the employee from the database based on the ID
    db_pool.query('DELETE FROM employees WHERE id = $1', [employeeId], (err) => {
        if (err) {
            // Handle the error
            console.error(err);
            res.status(500).send('Internal Server Error');
        } else {
            // Redirect to the list of employees or show a success message
            res.redirect('/employees');
        }
    });
    // Report employee entry
    router.post('/:id/entry', (req, res) => {
        const { id } = req.params;
        const eventType = 'entry'; // or 'check-in' as needed

        pool.query('INSERT INTO entry_exit_logs (employee_id, event_type) VALUES ($1, $2)', [id, eventType], (error) => {
            if (error) {
                console.error(error);
                return res.status(500).json({ error: 'Internal Server Error' });
            }

            res.status(201).json({ message: 'Entry event recorded successfully' });
        });
    });

// Report employee exit
    router.post('/:id/exit', (req, res) => {
        const { id } = req.params;
        const eventType = 'exit'; // or 'check-out' as needed

        pool.query('INSERT INTO entry_exit_logs (employee_id, event_type) VALUES ($1, $2)', [id, eventType], (error) => {
            if (error) {
                console.error(error);
                return res.status(500).json({ error: 'Internal Server Error' });
            }

            res.status(201).json({ message: 'Exit event recorded successfully' });
        });
        // Get entry and exit records for a specific employee
        router.get('/:id/entry-exit-records', (req, res) => {
            const { id } = req.params;
            pool.query('SELECT entry_time, exit_time FROM entry_exit_logs WHERE employee_id = $1', [id], (error, results) => {
                if (error) {
                    console.error(error);
                    return res.status(500).json({ error: 'Internal Server Error' });
                }
                res.json(results.rows);
            });
        });

    });

});

module.exports = router;


