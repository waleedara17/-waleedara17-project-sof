exports.HOST     = "localhost";
exports.USER     = "root";
exports.PASSWORD = "";
exports.DATABASE = "worker";